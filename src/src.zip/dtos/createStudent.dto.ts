

export class CreateStudentDto {
    
}